import java.util.*;
public class Check
{
public static void main(String a[])
{
int n;
Scanner sc= new Scanner(System.in);
System.out.println("Enter a number");
n=sc.nextInt();
if(n>0)
System.out.println("Positve");
else
System.out.println("Negative");
}
}